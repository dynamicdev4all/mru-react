import React, { useState } from 'react'

const Dashboard = (props) => {
    const name2 = "Shubham";
    const [count, setCount] = useState(0);
  return (
    <div>
      <h3>Hello, {props.name}</h3>
      <h3>Hello, {name2}</h3>
      <h3>Count : {count}</h3>
      <button className='btn btn-secondary' onClick={()=>setCount(count + 1)}>Increase</button>
      <button className='btn btn-primary' onClick={()=>setCount(count - 1)}>Decrease</button>
    </div>
  )
}

export default Dashboard
