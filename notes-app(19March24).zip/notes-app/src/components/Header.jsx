import React from 'react'

const Header = () => {

    //this means we can also use the jsx expression in the from of an Object. Here the headerStyle is an Object
    const headerStyle = {textAlign: 'center', background:'pink'};
  return (
    <div
    
    >
      <h1 style={headerStyle}>Notes Taking App [using OBJECT]</h1>
      <h1 style={{textAlign: 'center', background:'red'}}>Notes Taking App 2</h1>
    </div>
  )
}

// export default Header // this is the firsst way to export the component

export {Header} //this is the second way to export the component
