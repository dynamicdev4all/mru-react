import React from 'react'

const Field = () => {
  return (
    <div>
        <label>Note ID</label>
     <input className='form-control' type='text'></input> 
        <label>Note Name</label>
     <input className='form-control' type='text'></input> 
        <label>Note Date</label>
     <input className='form-control' type='text'></input> 
        <label>Note Description</label>
     <input className='form-control' type='text'></input> 
     <button className='btn btn-success' >Save Note</button>
     <button className='btn btn-info' >Load Note</button>
    </div>
  )
}

export default Field
