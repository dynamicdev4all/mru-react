import AddNotes from "./components/AddNotes";
// import PrintNotes from './components/PrintNotes'
import Header from "./components/Header";

function App() {
  return (
    <>
      <Header/>
      <AddNotes />
    </>
  );
}

export default App;
