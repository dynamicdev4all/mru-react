import logo from "./logo.svg";
import "./App.css";
import { Header } from "./components/Header";
import Dashboard from "./components/Dashboard";
import Note from "./components/Note";
import Nesting from "./components/Nesting";
import Field from "./components/Field";

function App() {
  return (
    <div className='container'
    
    
    >
      <Header />
      <Field/>
      {/* <Dashboard name="Vivek" />
      <Note />
      <Nesting /> */}
    </div>

    //  <div>
    //   <h1>This is React App</h1>
    //  </div>
  );
}

export default App;
