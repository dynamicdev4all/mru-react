import React from 'react'

const Note = () => {
    const isAvl = true;
    const isDefined = "YES";
    const isNotDefined = "NO";
  return (
    <div>
      {/* <p>This is note 1</p> */}
      <p>{(isAvl)?isDefined:isNotDefined}</p>
    </div>
  )
}

export default Note
